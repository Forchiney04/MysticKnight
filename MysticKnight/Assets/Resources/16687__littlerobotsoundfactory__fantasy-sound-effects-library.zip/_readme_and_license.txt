Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - LittleRobotSoundFactory ( https://freesound.org/people/LittleRobotSoundFactory/ )

You can find this pack online at: https://freesound.org/people/LittleRobotSoundFactory/packs/16687/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 270429__littlerobotsoundfactory__footstep-water-03.wav
    * url: https://freesound.org/s/270429/
    * license: Attribution
  * 270428__littlerobotsoundfactory__footstep-water-05.wav
    * url: https://freesound.org/s/270428/
    * license: Attribution
  * 270427__littlerobotsoundfactory__footstep-water-04.wav
    * url: https://freesound.org/s/270427/
    * license: Attribution
  * 270426__littlerobotsoundfactory__footstep-water-07.wav
    * url: https://freesound.org/s/270426/
    * license: Attribution
  * 270425__littlerobotsoundfactory__footstep-water-02.wav
    * url: https://freesound.org/s/270425/
    * license: Attribution
  * 270424__littlerobotsoundfactory__footstep-water-06.wav
    * url: https://freesound.org/s/270424/
    * license: Attribution
  * 270423__littlerobotsoundfactory__footstep-water-00.wav
    * url: https://freesound.org/s/270423/
    * license: Attribution
  * 270422__littlerobotsoundfactory__footstep-water-01.wav
    * url: https://freesound.org/s/270422/
    * license: Attribution
  * 270421__littlerobotsoundfactory__footstep-dirt-08.wav
    * url: https://freesound.org/s/270421/
    * license: Attribution
  * 270420__littlerobotsoundfactory__footstep-dirt-09.wav
    * url: https://freesound.org/s/270420/
    * license: Attribution
  * 270419__littlerobotsoundfactory__footstep-dirt-04.wav
    * url: https://freesound.org/s/270419/
    * license: Attribution
  * 270418__littlerobotsoundfactory__footstep-dirt-05.wav
    * url: https://freesound.org/s/270418/
    * license: Attribution
  * 270417__littlerobotsoundfactory__footstep-dirt-06.wav
    * url: https://freesound.org/s/270417/
    * license: Attribution
  * 270416__littlerobotsoundfactory__footstep-dirt-07.wav
    * url: https://freesound.org/s/270416/
    * license: Attribution
  * 270415__littlerobotsoundfactory__footstep-dirt-00.wav
    * url: https://freesound.org/s/270415/
    * license: Attribution
  * 270414__littlerobotsoundfactory__footstep-dirt-01.wav
    * url: https://freesound.org/s/270414/
    * license: Attribution
  * 270413__littlerobotsoundfactory__footstep-dirt-02.wav
    * url: https://freesound.org/s/270413/
    * license: Attribution
  * 270412__littlerobotsoundfactory__footstep-dirt-03.wav
    * url: https://freesound.org/s/270412/
    * license: Attribution
  * 270410__littlerobotsoundfactory__pickup-gold-04.wav
    * url: https://freesound.org/s/270410/
    * license: Attribution
  * 270409__littlerobotsoundfactory__spell-00.wav
    * url: https://freesound.org/s/270409/
    * license: Attribution
  * 270408__littlerobotsoundfactory__pickup-gold-00.wav
    * url: https://freesound.org/s/270408/
    * license: Attribution
  * 270407__littlerobotsoundfactory__pickup-gold-01.wav
    * url: https://freesound.org/s/270407/
    * license: Attribution
  * 270406__littlerobotsoundfactory__pickup-gold-02.wav
    * url: https://freesound.org/s/270406/
    * license: Attribution
  * 270405__littlerobotsoundfactory__pickup-gold-03.wav
    * url: https://freesound.org/s/270405/
    * license: Attribution
  * 270404__littlerobotsoundfactory__jingle-achievement-00.wav
    * url: https://freesound.org/s/270404/
    * license: Attribution
  * 270403__littlerobotsoundfactory__jingle-lose-00.wav
    * url: https://freesound.org/s/270403/
    * license: Attribution
  * 270402__littlerobotsoundfactory__jingle-win-00.wav
    * url: https://freesound.org/s/270402/
    * license: Attribution
  * 270401__littlerobotsoundfactory__menu-select-00.wav
    * url: https://freesound.org/s/270401/
    * license: Attribution
  * 270400__littlerobotsoundfactory__trap-01.wav
    * url: https://freesound.org/s/270400/
    * license: Attribution
  * 270399__littlerobotsoundfactory__trap-00.wav
    * url: https://freesound.org/s/270399/
    * license: Attribution
  * 270398__littlerobotsoundfactory__trap-02.wav
    * url: https://freesound.org/s/270398/
    * license: Attribution
  * 270397__littlerobotsoundfactory__spell-02.wav
    * url: https://freesound.org/s/270397/
    * license: Attribution
  * 270396__littlerobotsoundfactory__spell-01.wav
    * url: https://freesound.org/s/270396/
    * license: Attribution
  * 270395__littlerobotsoundfactory__spell-04.wav
    * url: https://freesound.org/s/270395/
    * license: Attribution
  * 270394__littlerobotsoundfactory__spell-03.wav
    * url: https://freesound.org/s/270394/
    * license: Attribution
  * 270393__littlerobotsoundfactory__inventory-open-00.wav
    * url: https://freesound.org/s/270393/
    * license: Attribution
  * 270392__littlerobotsoundfactory__inventory-open-01.wav
    * url: https://freesound.org/s/270392/
    * license: Attribution
  * 270391__littlerobotsoundfactory__goblin-01.wav
    * url: https://freesound.org/s/270391/
    * license: Attribution
  * 270390__littlerobotsoundfactory__goblin-02.wav
    * url: https://freesound.org/s/270390/
    * license: Attribution
  * 270389__littlerobotsoundfactory__goblin-03.wav
    * url: https://freesound.org/s/270389/
    * license: Attribution
  * 270388__littlerobotsoundfactory__goblin-04.wav
    * url: https://freesound.org/s/270388/
    * license: Attribution
  * 270387__littlerobotsoundfactory__ambience-cave-00.wav
    * url: https://freesound.org/s/270387/
    * license: Attribution
  * 270386__littlerobotsoundfactory__dragon-growl-00.wav
    * url: https://freesound.org/s/270386/
    * license: Attribution
  * 270385__littlerobotsoundfactory__dragon-growl-01.wav
    * url: https://freesound.org/s/270385/
    * license: Attribution
  * 270384__littlerobotsoundfactory__goblin-00.wav
    * url: https://freesound.org/s/270384/
    * license: Attribution


